package recursosHumanos.excecoes;

/**
 * Created by gilmario on 10/05/16.
 */
public class IdadeInvalidadeException extends Exception{
    public IdadeInvalidadeException(String message){
        super(message);
    }
}
