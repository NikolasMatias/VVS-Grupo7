package recursosHumanos.excecoes;

/**
 * Created by gilmario on 06/05/16.
 */
public class QuantidadeVagasExcedidaException extends Exception{
    public QuantidadeVagasExcedidaException(String message){
        super(message);
    }
}
