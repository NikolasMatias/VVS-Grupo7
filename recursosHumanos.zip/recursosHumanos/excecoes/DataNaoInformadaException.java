package recursosHumanos.excecoes;

/**
 * Created by gilmario on 10/05/16.
 */
public class DataNaoInformadaException extends Exception{
    public DataNaoInformadaException(String message){
        super(message);
    }
}
