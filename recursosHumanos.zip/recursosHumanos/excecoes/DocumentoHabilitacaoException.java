package recursosHumanos.excecoes;

public class DocumentoHabilitacaoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DocumentoHabilitacaoException(String message){
		super(message);
	}
}
