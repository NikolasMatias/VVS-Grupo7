package recursosHumanos.excecoes;

public class NacionalidadeInvalidaException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NacionalidadeInvalidaException(String message){
		super(message);
	}
}
