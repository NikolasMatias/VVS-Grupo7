package recursosHumanos.excecoes;

/**
 * Created by gilmario on 10/05/16.
 */
public class NomeInvalidoException extends Exception{
    public NomeInvalidoException(String message){
        super(message);
    }
}
