package recursosHumanos.excecoes;

/**
 * Created by gilmario on 10/05/16.
 */
public class CPFInvalidoException extends Exception{
    public CPFInvalidoException(String message){
        super(message);
    }
}
