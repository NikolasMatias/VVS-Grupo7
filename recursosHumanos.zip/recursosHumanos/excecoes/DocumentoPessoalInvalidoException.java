package recursosHumanos.excecoes;

public class DocumentoPessoalInvalidoException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DocumentoPessoalInvalidoException(String message){
		super(message);
	}
}
