package recursosHumanos.excecoes;

/**
 * Created by gilmario on 11/05/16.
 */
public class DocumentoReservistaInvalidoException extends Exception{
    public DocumentoReservistaInvalidoException(String message) {
        super(message);
    }
}
