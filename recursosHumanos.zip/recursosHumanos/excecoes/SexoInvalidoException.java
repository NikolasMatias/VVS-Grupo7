package recursosHumanos.excecoes;

/**
 * Created by gilmario on 11/05/16.
 */
public class SexoInvalidoException extends Exception{
    public SexoInvalidoException(String message){
        super(message);
    }
}
