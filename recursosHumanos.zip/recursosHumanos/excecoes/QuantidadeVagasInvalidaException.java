package recursosHumanos.excecoes;

/**
 * Created by gilmario on 11/05/16.
 */
public class QuantidadeVagasInvalidaException extends Exception{
    public QuantidadeVagasInvalidaException(String message) {
        super(message);
    }
}
