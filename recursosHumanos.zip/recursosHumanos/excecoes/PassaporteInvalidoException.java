package recursosHumanos.excecoes;

/**
 * Created by gilmario on 10/05/16.
 */
public class PassaporteInvalidoException extends Exception{
    public PassaporteInvalidoException(String message){
        super(message);
    }
}
