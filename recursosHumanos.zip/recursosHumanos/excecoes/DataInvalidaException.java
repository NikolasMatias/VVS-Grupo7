package recursosHumanos.excecoes;

/**
 * Created by gilmario on 10/05/16.
 */
public class DataInvalidaException extends Exception{

    public DataInvalidaException(String message){
        super(message);
    }
}
